# Kolumn - The Terraform for Your Entire Data Stack

## 🚀 **Elevator Pitch**

Kolumn is like Terraform, but instead of managing cloud infrastructure, it manages your **entire data stack** through a single interface.

**The Problem:**
Companies today have dozens of data tools - PostgreSQL, MySQL, Kafka, Airflow, dbt, Snowflake, etc. Each tool has its own way to manage schemas, configurations, and deployments. Teams spend 60% of their time just keeping everything in sync.

**The Solution:**
Kolumn gives you **one HCL configuration file** that defines your entire data infrastructure - databases, ETL pipelines, streaming systems, and even IoT devices. Change your config, run `kolumn apply`, and everything updates together safely.

**What makes it revolutionary:**
- **📝 Write once, deploy everywhere**: One config file for your entire data stack
- **🔄 Zero-downtime changes**: Intelligent migrations that never break production  
- **🔍 Auto-discovery**: Finds and imports your existing data infrastructure
- **🌐 Beyond databases**: Handles IoT sensors, streaming data, and real-time systems
- **🤖 AI-powered**: Automatically optimizes schemas and predicts issues

**The Result:**
Teams go from spending 3 days coordinating a simple schema change across their stack to making that same change in 3 minutes with confidence it won't break anything.

**In one sentence:** 
*"Kolumn is Terraform for data - manage your entire data infrastructure as code, from databases to IoT sensors, with intelligent automation that prevents outages."*

**Target Users:**
- Data Engineering teams managing complex data stacks
- Companies with IoT/sensor data that changes frequently  
- Organizations wanting infrastructure-as-code for their data layer

---

## 🏗️ Unified Infrastructure-as-Code for the Modern Data Stack

Kolumn is a revolutionary Terraform-style infrastructure-as-code tool that brings unified management to the entire modern data stack. Beyond traditional SQL schema management, Kolumn orchestrates databases, ETL pipelines, streaming platforms, data warehouses, and orchestration tools through a single declarative interface using HCL (HashiCorp Configuration Language).

## 🚀 Quick Start

### **Installation**

**🚀 One-Command Installation** (Recommended):
```bash
# Install latest Kolumn with automatic platform detection
curl -fsSL https://schemabounce.github.io/kolumn/install.sh | bash
```

**Manual Installation**:
```bash
# Download for your platform from GitHub Releases
wget https://github.com/schemabounce/kolumn/releases/latest/download/kolumn-linux-amd64
chmod +x kolumn-linux-amd64
sudo mv kolumn-linux-amd64 /usr/local/bin/kolumn
```

**Verify Installation**:
```bash
kolumn version                    # Check version
kolumn --help                     # See available commands
kolumn init                       # Create a new project
```

**🌐 Installation Features**:
- ✅ **Cross-Platform**: Linux, macOS, Windows support
- ✅ **Auto-Detection**: Automatic OS/architecture detection
- ✅ **Zero-Config**: No dependencies or complex setup
- ✅ **Version Management**: Always gets latest stable release
- ✅ **Path Integration**: Automatic PATH configuration

### **Getting Started**
```bash
# Create new Kolumn project
kolumn init my-data-stack

# Plan changes (dry run)
kolumn plan

# Apply changes  
kolumn apply

# View current state
kolumn state list
```

## 🚀 Revolutionary Features

### **Universal Data Stack Management**

**Core Repository (Foundation)**:
- **Kolumn CLI**: Universal command-line interface with HCL processing, 81-function library, and RPC plugin architecture
- **Kolumn Provider**: Built-in governance foundation for data classification, RBAC, and cross-provider coordination

**External Provider Ecosystem (30 Independent Repositories)**:
- **Database**: PostgreSQL, MySQL, SQLite, MSSQL, Redshift, BigQuery, Snowflake, Databricks, MongoDB, DynamoDB, InfluxDB
- **ETL/ELT**: Airbyte, dbt, Fivetran, Apache Spark  
- **Streaming**: Apache Kafka, Apache Pulsar, Amazon Kinesis
- **Orchestration**: Dagster, Prefect, Apache Airflow, Temporal
- **Storage**: Amazon S3, Azure Blob Storage, GCS, Delta Lake, Apache Iceberg
- **Cache**: Redis, Elasticsearch
- **Quality**: Great Expectations

### **Revolutionary HCL SQL System**
Makes infrastructure-as-code **EASIER** than raw SQL through intelligent automation:

```hcl
# Direct resource references (revolutionary!)
resource "postgres_table" "events" {
  column "user_id" {
    type = "bigint"
    references = postgres_table.users.id  # Direct resource reference!
  }
}

# Auto-join detection with override support
resource "cte" "active_users" {
  query {
    from { table { resource = "postgres_table.users" } }
    where = "status = 'active'"
  }
}

# Cross-provider integration (THE REVOLUTIONARY FEATURE!)
resource "airbyte_connection" "user_analytics" {
  source_query = cte.active_users  # Use PostgreSQL CTE as Airbyte source!
  destination = "snowflake_table.user_analytics"
}
```

### **Cross-Provider Intelligence**
- **Universal Resource References**: Use `postgres_table.users` across any provider type
- **Automatic Schema Extraction**: CTEs and views automatically provide schemas to downstream systems
- **Dependency Intelligence**: Automatic dependency tracking and cycle detection across provider boundaries
- **Type Safety**: Column-level type checking and validation across all providers

### **Enterprise-Ready State Management**
- **Universal State Adapters**: Every provider implements comprehensive state management
- **Multi-Backend Support**: Local, S3, Azure Blob, GCS, PostgreSQL, DynamoDB
- **State Migration**: Move state between backends with integrity verification
- **Backup & Recovery**: Automated backup creation with retention policies

## 🏗️ Modern Data Stack Unification

### Production-Ready Streaming Platform Example

**Location**: `/examples/streaming-platform/`

**Enterprise-Grade Components**:
- **12 Core Topics**: User events, orders, payments, inventory with proper partitioning
- **10 Consumer Groups**: Real-time analytics, fraud detection, ETL pipelines
- **Schema Registry**: Avro/JSON schemas with evolution policies
- **Kafka Connect**: Source (PostgreSQL CDC, MySQL, APIs) and Sink (Elasticsearch, S3, BigQuery) connectors
- **Multi-Environment**: Dev/staging/prod configurations with security
- **Monitoring**: Built-in observability and alerting integration

**Real-World Use Cases**:
- Real-time analytics dashboards (< 100ms latency)
- Event-driven order processing with exactly-once semantics
- Fraud detection with ML inference (< 50ms)
- Data lake ETL with Parquet storage
- Search index synchronization
- Error handling with dead letter queues

**Quick Start**:
```bash
cd examples/streaming-platform
./deploy.sh dev init
./deploy.sh dev apply
```

## 🛠️ Getting Started

### Prerequisites
- Go 1.22 or later
- Docker (for running tests and examples)

### Installation

#### **Ubuntu/Linux (Recommended)**
```bash
# One-line installer - installs CLI + core provider + sets up provider directory
curl -fsSL https://raw.githubusercontent.com/schemabounce/kolumn/main/install.sh | bash

# Or install .deb package directly (CLI only)
wget https://github.com/schemabounce/kolumn/releases/latest/download/kolumn_*_linux_amd64.deb
sudo dpkg -i kolumn_*_linux_amd64.deb

# Download core provider (governance functionality)
wget https://github.com/schemabounce/kolumn/releases/latest/download/kolumn-core-provider_*_linux_amd64.tar.gz
tar -xzf kolumn-core-provider_*_linux_amd64.tar.gz
mkdir -p ~/.kolumn/providers
mv kolumn-provider-kolumn ~/.kolumn/providers/
chmod +x ~/.kolumn/providers/kolumn-provider-kolumn
```

#### **External Providers (Install as Needed)**
```bash
# Install specific providers from their independent repositories
curl -L https://github.com/kolumn-io/provider-postgres/releases/latest/download/kolumn-provider-postgres > ~/.kolumn/providers/kolumn-provider-postgres
curl -L https://github.com/kolumn-io/provider-kafka/releases/latest/download/kolumn-provider-kafka > ~/.kolumn/providers/kolumn-provider-kafka  
curl -L https://github.com/kolumn-io/provider-dbt/releases/latest/download/kolumn-provider-dbt > ~/.kolumn/providers/kolumn-provider-dbt
chmod +x ~/.kolumn/providers/*

# Or use automatic provider discovery
kolumn init --download-providers  # Downloads all providers you reference in your config
```

#### **Docker (GHCR)**
```bash
# Pull from GitHub Container Registry (CLI + core provider only)
docker pull ghcr.io/schemabounce/kolumn:latest
docker run --rm ghcr.io/schemabounce/kolumn:latest --help

# External providers must be mounted or installed separately
echo 'alias kolumn="docker run --rm -v \$(pwd):/workspace -v ~/.kolumn/providers:/providers -w /workspace ghcr.io/schemabounce/kolumn:latest"' >> ~/.bashrc
```

#### **Go Install (Development)**
```bash
# Install core CLI (governance provider included)
go install github.com/schemabounce/kolumn@latest

# External providers must be compiled separately from their repositories
```

For complete installation options including .rpm packages, ARM64 support, and more, see [INSTALLATION.md](INSTALLATION.md).

### 📖 Documentation

**New to Kolumn?** Start with the [Complete Documentation](docs/README.md) for guides, examples, and architecture details.

**Quick Links:**
- 🏗️ [Architecture Overview](docs/architecture/README.md) - How Kolumn works
- ⚡ [Examples](examples/README.md) - Working code examples  
- 👨‍💻 [Development Setup](docs/development/README.md) - Contributing guide
- 🏢 [Enterprise Deployment](docs/enterprise/README.md) - Production setup

### Core Workflow

```bash
# Initialize a new Kolumn project
kolumn init

# Preview changes across all provider types
kolumn plan

# Apply changes across all provider types
kolumn apply

# Remove managed resources
kolumn destroy

# Check current version
kolumn version
```

### 🏷️ Automated Semantic Versioning

Kolumn uses automated semantic versioning with conventional commits for streamlined releases:

```bash
# Setup versioning (one-time)
make setup-versioning

# Check current version info
make version-info

# Preview potential version bump
make check-version

# Use conventional commit patterns
git commit -m "feat(provider): add Redis cache support"    # MINOR bump
git commit -m "fix(database): resolve connection timeout"  # PATCH bump  
git commit -m "break(api)!: remove deprecated methods"     # MAJOR bump
```

**Branch Strategy**:
- **`develop`**: Development pre-releases (e.g., `v1.2.3-dev.202501301245`)
- **`main`**: Production releases (e.g., `v1.2.3`) with full asset builds

### 🛡️ Pre-commit Test Validation

Intelligent pre-commit hooks ensure code quality by testing only changed files:

```bash
# Setup pre-commit hooks (one-time)
make setup-hooks

# Test hook functionality
make test-hooks

# Hooks run automatically on every commit
git commit -m "feat: add new feature"  # Auto-validates changed code
```

**What gets validated**:
- ✅ **Go syntax & formatting** - Ensures compilable, formatted code
- ✅ **Targeted testing** - Runs tests only for changed packages  
- ✅ **Provider compliance** - Validates state adapters and interfaces
- ✅ **Quality checks** - Linting, race detection, merge conflict detection

See [PRE_COMMIT_HOOKS.md](PRE_COMMIT_HOOKS.md) and [VERSIONING.md](VERSIONING.md) for complete documentation.

### **🔥 Multi-Provider Enterprise Pipeline**

```hcl
# =============================================================================
# DATABASE PROVIDERS - Production-Ready Database Management
# =============================================================================

# PostgreSQL - Advanced features with state management
provider "postgres" {
  type = "database"
  host = "postgres.company.com"
  port = 5432
  database = "production_analytics"
  sslmode = "require"
}

resource "postgres_table" "users" {
  schema = "public"
  
  column "id" {
    type = "bigserial"
    primary_key = true
  }
  
  column "email" {
    type = "varchar(255)"
    unique = true
    not_null = true
  }
  
  column "created_at" {
    type = "timestamptz"
    default = "now()"
  }
  
  index "idx_users_created_at" {
    columns = ["created_at"]
    method = "btree"
  }
}

# MySQL - 100% Feature Parity with PostgreSQL
provider "mysql" {
  type = "database"
  host = "mysql.company.com"
  port = 3306
  database = "legacy_system"
}

resource "mysql_table" "orders" {
  engine = "InnoDB"
  charset = "utf8mb4"
  
  column "order_id" {
    type = "bigint"
    auto_increment = true
    primary_key = true
  }
  
  column "user_id" {
    type = "bigint"
    references = postgres_table.users.id  # Cross-provider reference!
  }
}

# MSSQL - Enterprise Features (50 Object Types)
provider "mssql" {
  type = "database"
  server = "sqlserver.company.com"
  database = "enterprise_dwh"
  integrated_security = true
}

resource "mssql_table" "sales_facts" {
  schema = "analytics"
  
  column "sale_id" {
    type = "bigint"
    identity = true
  }
  
  # Columnstore index for analytics
  index "ccx_sales_facts" {
    type = "columnstore"
    clustered = true
  }
}

# =============================================================================  
# ETL/ELT PROVIDERS - Data Pipeline Orchestration
# =============================================================================

# Airbyte - Complete API Integration
provider "airbyte" {
  type = "etl"
  api_url = "https://airbyte.company.com"
  basic_auth {
    username = var.airbyte_user
    password = var.airbyte_password
  }
}

resource "airbyte_connection" "postgres_to_snowflake" {
  source_id = airbyte_source.postgres_prod.id
  destination_id = airbyte_destination.snowflake_dw.id
  
  sync_catalog {
    stream "public.users" {
      sync_mode = "incremental"
      cursor_field = "created_at"
      destination_sync_mode = "append_dedup"
    }
  }
  
  schedule {
    units = 3600  # Every hour
    time_unit = "seconds"
  }
}

# dbt - Complete Model Lifecycle
provider "dbt" {
  type = "etl"
  profiles_dir = "./profiles"
  project_dir = "./dbt_project"
}

resource "dbt_model" "user_analytics" {
  name = "user_analytics"
  
  sql = <<SQL
    {{ config(materialized='incremental') }}
    
    select 
      user_id,
      count(*) as order_count,
      sum(amount) as total_spent
    from {{ ref('orders') }}
    {% if is_incremental() %}
      where created_at > (select max(created_at) from {{ this }})
    {% endif %}
    group by user_id
  SQL
  
  tests = [
    "unique:user_id",
    "not_null:user_id,order_count"
  ]
}

# =============================================================================
# STREAMING PROVIDERS - Real-time Data Processing  
# =============================================================================

# Kafka - Enterprise Streaming Platform
provider "kafka" {
  type = "streaming"
  bootstrap_servers = ["kafka1:9092", "kafka2:9092", "kafka3:9092"]
  security_protocol = "SASL_SSL"
  sasl_mechanism = "SCRAM-SHA-512"
}

resource "kafka_topic" "user_events" {
  name = "user.events.v1"
  partitions = 12
  replication_factor = 3
  
  config = {
    "cleanup.policy" = "delete"
    "retention.ms" = "604800000"  # 7 days
    "compression.type" = "lz4"
  }
}

# Pulsar - Advanced Message Queuing
provider "pulsar" {
  type = "streaming"
  service_url = "pulsar://pulsar.company.com:6650"
}

resource "pulsar_topic" "order_events" {
  tenant = "production"
  namespace = "ecommerce"
  topic = "order-events"
  partitions = 8
}

# =============================================================================
# ORCHESTRATION PROVIDERS - Workflow Management
# =============================================================================

# Dagster - Asset-Based Data Engineering
provider "dagster" {
  type = "orchestration" 
  graphql_url = "https://dagster.company.com/graphql"
}

resource "dagster_pipeline" "daily_analytics" {
  name = "daily_analytics_pipeline"
  
  schedule {
    cron_schedule = "0 2 * * *"  # 2 AM daily
    timezone = "UTC"
  }
  
  asset "user_metrics" {
    depends_on = [dbt_model.user_analytics]
    compute_kind = "sql"
  }
}

# Prefect - Modern Dataflow Automation
provider "prefect" {
  type = "orchestration"
  api_url = "https://prefect.company.com/api"
}

resource "prefect_flow" "etl_pipeline" {
  name = "etl_pipeline"
  
  task "extract_data" {
    type = "python"
    depends_on = [airbyte_connection.postgres_to_snowflake]
  }
}

# Airflow - Traditional DAG Management
provider "airflow" {
  type = "orchestration"
  webserver_url = "https://airflow.company.com"
}

resource "airflow_dag" "data_pipeline" {
  dag_id = "data_pipeline_v1"
  schedule_interval = "@daily"
  
  task "process_orders" {
    operator = "BashOperator"
    bash_command = "kolumn apply --target=mysql_table.orders"
  }
}

# =============================================================================
# STORAGE PROVIDERS - Cloud Storage Management
# =============================================================================

# S3 - AWS Storage with Lifecycle Management
provider "s3" {
  type = "storage"
  region = "us-east-1"
}

resource "s3_bucket" "data_lake" {
  name = "company-data-lake-prod"
  
  lifecycle_configuration {
    rule "transition_ia" {
      transition {
        days = 30
        storage_class = "STANDARD_IA"
      }
    }
    
    rule "archive_glacier" {
      transition {
        days = 90
        storage_class = "GLACIER"  
      }
    }
  }
  
  notification {
    topic = "arn:aws:sns:us-east-1:123456789:data-lake-events"
    events = ["s3:ObjectCreated:*"]
  }
}

# Azure Blob - Microsoft Cloud Storage
provider "azure" {
  type = "storage"
  storage_account = "companystorage"
}

resource "azure_container" "analytics_data" {
  name = "analytics-data"
  access_type = "private"
  
  lifecycle_policy {
    rule "delete_old_logs" {
      filters {
        blob_types = ["blockBlob"]
        prefix_match = ["logs/"]
      }
      actions {
        delete {
          days_after_modification = 90
        }
      }
    }
  }
}

# =============================================================================
# 🆕 SCHEMA MANAGEMENT PROVIDERS - Git-Integrated ORM Management
# =============================================================================

# TypeORM - TypeScript-First Development
provider "typeorm" {
  type = "schema_management"
  connection_file = "./ormconfig.json"
  entities_dir = "./src/entities"
}

resource "typeorm_entity" "User" {
  table_name = "users"
  
  column "id" {
    type = "bigint"
    primary = true
    generated = "increment"
  }
  
  column "email" {
    type = "varchar"
    unique = true
  }
  
  relations {
    one_to_many "orders" {
      target = "Order"
      join_column = "user_id"
    }
  }
}

# Prisma - Schema-First Development  
provider "prisma" {
  type = "schema_management"
  schema_file = "./prisma/schema.prisma"
}

resource "prisma_model" "Order" {
  fields {
    id = "Int @id @default(autoincrement())"
    userId = "Int"
    amount = "Decimal"
    user = "User @relation(fields: [userId], references: [id])"
  }
}

# SQLAlchemy - Python ORM with Alembic
provider "sqlalchemy" {
  type = "schema_management"
  database_url = "postgresql://user:pass@localhost/db"
  models_module = "app.models"
}

resource "sqlalchemy_model" "Product" {
  table_name = "products"
  
  column "id" {
    type = "Integer"
    primary_key = true
  }
  
  column "name" {
    type = "String(255)"
    nullable = false
  }
}
```

## 🏗️ Revolutionary Provider Architecture

### **True Terraform-Style Separation**
Kolumn achieves what no other infrastructure-as-code tool has accomplished: **complete provider ecosystem independence**.

**Core Repository (This Repository)**:
- **Kolumn CLI**: Universal command-line interface with full HCL processing
- **RPC Infrastructure**: Plugin discovery, download, and management system  
- **Provider Development SDK**: Complete toolkit for building external providers with RPC interface, testing framework, and code generation
- **Function Library**: 81 universal functions available across all providers
- **Kolumn Provider**: Governance foundation for classification, RBAC, and cross-provider coordination

**External Provider Repositories (30 Independent Repositories)**:
- Each provider lives in its own GitHub repository with independent versioning
- Built using **Kolumn Provider SDK** for standardized development experience
- Providers are automatically discovered as `kolumn-provider-*` binaries
- Full CRUD operations via universal 4-method RPC interface: `Configure`, `GetSchema`, `CallFunction`, `Close`
- Independent CI/CD, testing, and release cycles with SDK tooling

### **Provider Discovery & Installation**

```bash
# Automatic provider discovery and installation
kolumn init --download-providers

# Manual provider installation from independent repositories
curl -L https://github.com/kolumn-io/provider-postgres/releases/latest/download/kolumn-provider-postgres > ~/.kolumn/providers/
curl -L https://github.com/kolumn-io/provider-kafka/releases/latest/download/kolumn-provider-kafka > ~/.kolumn/providers/
chmod +x ~/.kolumn/providers/*

# Providers are automatically discovered during kolumn operations
kolumn plan  # Automatically detects and uses available providers
```

### **External Provider Categories**

| Category | Repositories | Independent Releases | RPC Interface |
|----------|--------------|---------------------|---------------|
| **Database (11)** | `kolumn-io/provider-postgres`, `provider-mysql`, `provider-sqlite`, `provider-mssql`, `provider-bigquery`, `provider-snowflake`, `provider-redshift`, `provider-databricks`, `provider-mongodb`, `provider-dynamodb`, `provider-influxdb` | ✅ Independent | ✅ Universal |
| **ETL/ELT (4)** | `kolumn-io/provider-airbyte`, `provider-dbt`, `provider-fivetran`, `provider-spark` | ✅ Independent | ✅ Universal |
| **Streaming (3)** | `kolumn-io/provider-kafka`, `provider-pulsar`, `provider-kinesis` | ✅ Independent | ✅ Universal |
| **Orchestration (4)** | `kolumn-io/provider-dagster`, `provider-prefect`, `provider-airflow`, `provider-temporal` | ✅ Independent | ✅ Universal |
| **Storage (5)** | `kolumn-io/provider-s3`, `provider-azureblob`, `provider-gcs`, `provider-deltalake`, `provider-iceberg` | ✅ Independent | ✅ Universal |
| **Cache (2)** | `kolumn-io/provider-redis`, `provider-elasticsearch` | ✅ Independent | ✅ Universal |
| **Quality (1)** | `kolumn-io/provider-greatexpectations` | ✅ Independent | ✅ Universal |

### **Competitive Advantages**

1. **First-to-Market**: Only infrastructure-as-code tool with true provider ecosystem separation
2. **Unlimited Extensibility**: Anyone can create providers without touching core repository
3. **Independent Development**: Provider teams can develop, test, and release independently  
4. **Reduced Dependencies**: Core repository focuses only on CLI and governance
5. **Terraform Compatibility**: Familiar plugin architecture and discovery patterns

### **🎉 Core Repository Achievements**

#### **Universal CLI Foundation**
- **🏆 81 Universal Functions**: Complete function library (270% over 30+ target)  
- **🏆 6 HCL Evaluation Contexts**: Variables, Outputs, Locals, Modules, DataSources, Evaluator - all with full function access
- **🏆 100% Function Integration**: Centralized registry with universal availability
- **🏆 Variable System**: Complete precedence tracking (CLI > Environment > .klvars > Defaults)
- **🏆 Module System**: Data-focused CLI with 4 complete commands (list, show, validate, init)
- **🏆 RPC Plugin Architecture**: Universal 4-method interface for unlimited provider extensibility

#### **Governance Foundation (Kolumn Provider)**
- **🏆 Data Classification System**: PII, Sensitive, Public with encryption requirements
- **🏆 Universal RBAC**: Cross-provider role-based access control with data masking
- **🏆 Cross-Provider Coordination**: Unified governance across all 30 external providers
- **🏆 Enterprise Encryption**: Database-native key derivation with 80% key reduction

#### **External Provider Ecosystem** 
- **🏆 30 Independent Repositories**: True Terraform-style provider separation achieved
- **🏆 Universal RPC Interface**: All providers implement the same 4-method interface
- **🏆 Automatic Discovery**: Plugin system automatically finds `kolumn-provider-*` binaries
- **🏆 Independent Development**: Each provider has its own CI/CD, testing, and release cycles
- **🏆 Production-Grade Testing**: Each provider repository includes comprehensive test suites

## 📊 Comprehensive Testing Coverage

### **State Adapter Testing**
- **Universal Test Framework**: Standardized testing for all provider state adapters
- **Coverage**: MySQL, PostgreSQL, Airbyte, Kafka, S3, Prefect, Dagster
- **Test Areas**: State conversion, dependency extraction, drift detection, validation, metadata handling
- **Provider-Specific Features**: Security configurations, data governance, performance optimization

### **Integration Testing**
- **Testbeds**: Comprehensive testing environments for all provider types
- **Resource References**: Revolutionary direct resource reference testing
- **Cross-Provider**: Multi-provider pipeline testing and validation
- **Real-World Scenarios**: Production-grade streaming platform examples

## 🔧 Development Setup

### Quick Start for New Developers

**One-command setup:**
```bash
# Clone repository and run setup script
git clone https://github.com/schemabounce/kolumn.git
cd kolumn
./setup-dev.sh
```

This script will:
- ✅ Verify Go 1.23+ installation
- ✅ Download all dependencies  
- ✅ Build the Kolumn binary
- ✅ Configure Git pre-commit hooks
- ✅ Check for recommended tools (jq, make)

### Pre-Commit Hooks (Recommended)

**Enhanced Quality Gates** - Our pre-commit hooks run comprehensive checks before every commit:

```bash
# Setup hooks (run once)
.githooks/setup-hooks.sh

# Pre-commit hooks automatically run:
# 1. 📝 Go code formatting (gofmt) 
# 2. 📝 HCL/Kolumn file formatting
# 3. 🔍 Static analysis (go vet)
# 4. 🧪 Full unit test suite
# 5. 🔍 Code quality checks

# Skip hooks temporarily (not recommended)
git commit --no-verify
```

**Benefits:**
- **🚀 Saves CI Minutes**: Tests run locally instead of in GitHub Actions
- **⚡ Faster Feedback**: Catch issues in ~30-60s instead of waiting for CI
- **🔒 Prevents Broken Commits**: No more failing builds due to formatting/test issues
- **📊 Full Coverage**: Same comprehensive checks as CI, but local-first

**CI/CD Pipeline Changes:**
- 🎯 **Streamlined CI**: GitHub Actions now focuses on build verification and deployment
- ⚡ **Faster Builds**: CI runs only essential checks (compile, basic build test)
- 💰 **Cost Effective**: Reduces GitHub Actions minutes by ~80%
- 🔄 **Developer-First**: Quality gates moved to pre-commit for immediate feedback

### Development Commands

### Build and Testing
```bash
# Build the binary
make build

# Install locally
make install

# Run all tests with coverage
make test

# Run specific package tests
go test ./pkg/sql/parser/...

# Lint code (requires golangci-lint)
make lint

# Run all checks (vet, lint, test)
make check
```

### Provider-Specific Commands
```bash
# Database operations
kolumn db plan
kolumn db apply
kolumn db migrate --version=latest

# Multi-provider pipeline commands
kolumn pipeline plan --name=user_analytics
kolumn pipeline apply --name=user_analytics
kolumn pipeline status --name=user_analytics
```

### State Management Commands
```bash
# Initialize state management
kolumn state init

# Show current state
kolumn state show

# Migrate state between backends
kolumn state migrate -from=local -to=s3 -backup

# Create state backup
kolumn state backup -location=./backups/
```

## 🎨 Code Generation

Kolumn provides comprehensive code generation for multiple languages with provider-specific optimization:

```bash
# Generate models using provider-specific templates
kolumn generate models --language=java --package=com.acme.models

# Generate Kafka producers (uses kafka_producer template)
kolumn generate producers --topic=user-events --language=java

# Generate Pulsar producers (uses pulsar_producer template)  
kolumn generate producers --topic=user-events --provider=pulsar --language=java
```

## 📚 Architecture

### **Design Principles**
1. **Schema-Focused Management**: Manages schemas and metadata within existing infrastructure
2. **No Infrastructure Overlap**: Complements Terraform by focusing on data-level object management
3. **Provider-Aware State**: Database backends only available when their providers are active
4. **Universal State Management**: Every provider implements comprehensive state adapters
5. **Enterprise Ready**: Built-in encryption, compliance, audit logging, and governance

### **Revolutionary Resource Reference System**
- **Direct References**: `postgres_table.users.id` instead of string-based references
- **Auto-Join Detection**: Automatic foreign key relationship detection with manual overrides
- **Cross-Provider CTEs**: PostgreSQL CTEs usable as Airbyte sources with automatic schema extraction
- **Universal Dependency Tracking**: Automatic dependency resolution across all provider types

### **Enhanced State Management**
- **Universal State Adapters**: All providers implement comprehensive state conversion
- **Cross-Provider Dependencies**: Intelligent dependency mapping across provider boundaries
- **Drift Detection**: Provider-specific configuration drift detection with actionable recommendations
- **Multi-Backend Support**: Local, cloud, and database backends with automatic provider registration

## 🤝 Contributing

We welcome contributions! Please see our comprehensive documentation:

### 📚 Documentation
- **[Complete Documentation](docs/README.md)** - Start here for everything you need to know
- **[Architecture Guide](docs/architecture/README.md)** - System design and components
- **[Development Setup](docs/development/README.md)** - Complete development environment setup
- **[Provider System](docs/providers/README.md)** - Adding new providers and integrations
- **[Testing Guide](docs/development/testing-guide.md)** - Unit, integration, and E2E testing
- **[Enterprise Deployment](docs/enterprise/README.md)** - Production deployment guide
- **[CLAUDE.md](CLAUDE.md)** - AI assistant context and project instructions

### **Key Contribution Areas**

**Core Repository (This Repository)**:
- **CLI Enhancements**: Improve universal commands, HCL processing, and function library
- **Governance System**: Enhance data classification, RBAC, and cross-provider coordination  
- **RPC Infrastructure**: Improve plugin discovery, management, and communication
- **Documentation**: Expand guides, examples, and developer resources

**External Provider Repositories**:
- **New Providers**: Create independent repositories for additional data stack tools
- **Provider Enhancement**: Improve existing providers in their respective repositories
- **Testing Coverage**: Expand provider-specific test suites and integration tests
- **Provider SDK Enhancement**: Improve the SDK for easier provider development and better developer tooling

**Find External Providers**: Visit [kolumn-io organization](https://github.com/kolumn-io) for all 30 provider repositories

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Terraform**: Inspired the declarative infrastructure-as-code approach
- **HCL 2.0**: Provides the powerful configuration language foundation
- **Modern Data Stack**: Built to unify the fragmented data tooling ecosystem
- **Enterprise Data Teams**: Designed for production-grade data infrastructure management

---

**Kolumn makes managing the entire modern data stack as easy as a single `terraform apply` - but for your data infrastructure.**